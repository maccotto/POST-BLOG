/*
Azure SQL monitoring
*/

-- Analisis consumos de recursos

SELECT 
    end_time AS TimeStamp,
    (SELECT AVG(avg_cpu_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) AS CPU_Percent_Average,
    (SELECT AVG(avg_data_io_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) AS IO_Percent_Average,
    (SELECT AVG(avg_memory_usage_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) AS Memory_Percent_Average,
    (SELECT AVG(avg_log_write_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) AS Log_Write_Percent_Average,
    dtu_limit AS DTU_Limit,
    (SELECT AVG(avg_cpu_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) / 100 * dtu_limit AS CPU_Limit,
    (SELECT AVG(avg_data_io_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) / 100 * dtu_limit AS IO_Limit,
    (SELECT AVG(avg_memory_usage_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) / 100 * dtu_limit AS Memory_Limit,
    (SELECT AVG(avg_log_write_percent) FROM sys.dm_db_resource_stats WHERE end_time = rs.end_time) / 100 * dtu_limit AS Log_Write_Limit
FROM 
    sys.dm_db_resource_stats rs
ORDER BY 
    end_time DESC;

-- Consultas

SELECT TOP 10
    qs.total_worker_time/1000.0 AS Total_CPU_Time_Seconds,
    qs.total_logical_reads + qs.total_logical_writes AS Total_Logical_IO,
    qs.execution_count AS Execution_Count,
    SUBSTRING(qt.text,qs.statement_start_offset/2, 
        (CASE 
            WHEN qs.statement_end_offset = -1 
            THEN LEN(CONVERT(nvarchar(max), qt.text)) * 2 
            ELSE qs.statement_end_offset 
        END - qs.statement_start_offset)/2
    ) AS query_text
FROM 
    sys.dm_exec_query_stats qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
ORDER BY 
    Total_Logical_IO DESC;
