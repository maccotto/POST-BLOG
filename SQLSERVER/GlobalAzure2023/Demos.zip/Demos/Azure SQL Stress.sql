use Adventureworks 
go

drop table if exists carga

create table carga (it int identity primary key,
                    f datetime,
					c1 char(200),
					c2 char(200),
					c3 char(300),
					c4 char(400)
					)

insert into carga (f,c1,c2,c3,c4) values (getdate(),'h','o','l','a')

ostress.exe -n255 -r10000 -S. -E -dAdventureWorks -Q"insert into carga (f,c1,c2,c3,c4) values (getdate(),'h','o','l','a') "

