/* 
Bloqueos
*/

use AdventureWorks 
go

-- sesion 1
begin tran
SELECT * FROM Production.Product WITH (TABLOCKX)

-- sesion 2
/*
ostress.exe -n10 -r1 -S. -E -dAdventureWorks -q -Q"SELECT * FROM Production.Product where ProductID = 1"

*/

-- minoitoreo de bloqueos

exec sp_whoisactive
