﻿# Carga de trabajp MSSQL

# Configurar las credenciales de SQL Server
$serverName = "localhost"
$databaseName = "AdventureWorks2019"
$username = "sa"
$password = "Passw0rd."

# Establecer la conexión con la base de datos
$connectionString = "Server=$serverName;Database=$databaseName;User ID=$username;Password=$password;"
$connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
$connection.Open()

# Generar una consulta aleatoria a varias tablas
$random = New-Object System.Random

for ($i = 1; $i -le 10000; $i++) {
    # Calcular el porcentaje de progreso
    $percentComplete = [int]($i / 10000 * 100)

    # Actualizar la barra de progreso
    $status = "Realizando consulta $i de 10000"
    Write-Progress -Activity "Carga de trabajo de lectura" -Status $status -PercentComplete $percentComplete

    # Tabla Sales.Customer
    $customerId = $random.Next(1, 1000)
    $query = "SELECT * FROM Sales.Customer WHERE CustomerID = $customerId"
    $command = New-Object System.Data.SqlClient.SqlCommand($query, $connection)
    $reader = $command.ExecuteReader()
    $reader.Close()

    # Tabla Production.Product
    $productId = $random.Next(1, 500)
    $query = "SELECT * FROM Production.Product WHERE ProductID = $productId"
    $command = New-Object System.Data.SqlClient.SqlCommand($query, $connection)
    $reader = $command.ExecuteReader()
    $reader.Close()

    # Tabla Sales.SalesOrderDetail
    $orderDetailId = $random.Next(1, 10000)
    $query = "SELECT * FROM Sales.SalesOrderDetail WHERE SalesOrderDetailID = $orderDetailId"
    $command = New-Object System.Data.SqlClient.SqlCommand($query, $connection)
    $reader = $command.ExecuteReader()
    $reader.Close()

    # Tabla Sales.SalesOrderHeader
    $orderHeaderId = $random.Next(1, 1000)
    $query = "SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = $orderHeaderId"
    $command = New-Object System.Data.SqlClient.SqlCommand($query, $connection)
    $reader = $command.ExecuteReader()
    $reader.Close()
}

# Cerrar la conexión
$connection.Close()
