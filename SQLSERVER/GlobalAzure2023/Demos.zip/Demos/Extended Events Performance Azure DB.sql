/*
 Extended event Azure
*/

CREATE MASTER KEY
DROP DATABASE SCOPED CREDENTIAL [https://bssql.blob.core.windows.net/sql]


CREATE DATABASE SCOPED CREDENTIAL [https://bssql.blob.core.windows.net/sql]
WITH  IDENTITY = 'SHARED ACCESS SIGNATURE',  -- "SAS" token.
        -- TODO: Paste in the long SasToken string here for Secret, but exclude any leading '?'.
        SECRET = 'sp=racwdli&st=2023-05-11T15:46:35Z&se=2023-05-21T23:46:35Z&spr=https&sv=2022-11-02&sr=c&sig=tZo%2BUvVlaVHjXXl14%2FDJYy524WewbySH2WDvIRXoGzQ%3D'
    ;

-- Exteneded events para query tuning
CREATE EVENT SESSION [TRIGGERDB_PERFORMANCE] ON DATABASE 
ADD EVENT sqlserver.rpc_completed(SET collect_data_stream=(1)
    ACTION(package0.event_sequence,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.client_pid,sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.request_id,sqlserver.session_id,sqlserver.sql_text,sqlserver.transaction_id,sqlserver.username)
	  WHERE ( ( duration >= ( 100000 ) )
            )),
ADD EVENT sqlserver.sql_batch_completed(SET collect_batch_text=(1)
    ACTION(package0.event_sequence,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.client_pid,sqlserver.database_id,sqlserver.database_name,sqlserver.query_hash,sqlserver.request_id,sqlserver.session_id,sqlserver.sql_text,sqlserver.transaction_id,sqlserver.username)
	  WHERE ( ( duration >= ( 100000 ) )
            )
	  )
ADD TARGET package0.event_file(
SET filename = N'https://bssql.blob.core.windows.net/sql/query1.xel',
     metadatafile=N'https://bssql.blob.core.windows.net/sql/query2.xem')
WITH (MAX_MEMORY=4096 KB)
GO


