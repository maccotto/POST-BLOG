-- Carga de trabajo Azure DB

Use Adventureworks 
go

DECLARE @random_value INT;
SET @random_value = (SELECT ABS(CHECKSUM(NewId())) % (900 - 710 + 1) + 710);

DECLARE @random_value2 INT;
SET @random_value2 = (SELECT ABS(CHECKSUM(NewId())) % (300 - 0 + 1) + 300);


Select * from SalesLT.Product where productid=@random_value

select * from [SalesLT].[SalesOrderDetail] d
inner join [SalesLT].[Product] p
on d.ProductID = p.ProductID 
where d.productid = @random_value
order by 1 desc


select * from [SalesLT].[SalesOrderDetail] d
inner join [SalesLT].[Product] p
on d.ProductID = p.ProductID 
where d.productid = @random_value

select top(50) * from [SalesLT].[Customer]
where upper(customerID) < @random_value2
